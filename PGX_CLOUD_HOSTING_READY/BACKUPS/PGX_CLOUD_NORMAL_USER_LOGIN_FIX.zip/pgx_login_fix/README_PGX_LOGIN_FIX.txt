PGX CLOUD - NORMAL USER LOGIN PATCH

Files in this patch:
- app.py
- templates/login.html

Apply safely:
1. Back up the live app.py and templates/login.html first.
2. Upload/replace these two files at the same application root and templates folder.
3. Do NOT replace users.json, bots/, any .db file, logs, or .pgx_secret_key.
4. Restart the Flask/WSGI application.

Changes:
- /login accepts normal user accounts as well as admin accounts.
- Normal users are redirected to /account after login (or /free-claim when next=claim).
- Supports password_hash and legacy plaintext password records.
- On successful legacy login, plaintext password is upgraded to a Werkzeug password hash.
- Project-specific login also uses the same password verification helper.
- Disabled accounts are blocked.

Google OAuth is still dependent on correct GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET,
and GOOGLE_REDIRECT_URI environment settings in the hosting environment.

Validation: Python syntax compilation passed. Full live-host/Google OAuth integration
cannot be confirmed from this patch alone.
