PGX CLOUD - UPDATED HOSTING PANEL
=================================

What was updated
----------------
- Rebranded the existing interface to PGX CLOUD (neon purple/blue styling).
- Preserved the existing Flask/Python hosting backend and existing project folders.
- Added SYCO as the primary admin login. On first startup, the legacy `admin`
  account is migrated to SYCO and the password is set to SYCO123.
- Admin passwords are stored as Werkzeug password hashes.
- Added multiple-admin creation from the admin dashboard.
- Added live host CPU/RAM/disk overview.
- Added project inventory with per-project RAM/disk/CPU settings.
- Added an admin project inspector for project files, SQLite database tables
  and row counts, and the latest output.log lines.
- Added an admin activity audit log.
- Added login/session checks for project APIs and path checks for file operations
  and ZIP extraction.
- Added RAM monitoring for bot processes. A process is stopped if its measured
  resident memory exceeds its configured RAM value.
- Disabled Flask debug mode and added a persistent generated session secret.
- Added missing `psutil` and `requests` dependencies.

Run
---
1. Install Python 3.9+.
2. In the project directory run:
      python -m pip install -r requirements.txt
3. Start:
      python app.py
4. Open:
      http://127.0.0.1:5000/login
5. First admin login:
      Username: SYCO
      Password: SYCO123

IMPORTANT SECURITY / CAPACITY NOTES
-----------------------------------
- Change the initial SYCO password immediately after first login and keep the
  server private until the deployment is hardened.
- This application executes customer Python projects as child processes of the
  Flask service. It is NOT an OS/container sandbox. Do not offer public,
  untrusted multi-tenant hosting on a production server until projects are
  isolated using Docker/containerd or separate OS users with strict CPU, RAM,
  filesystem and network policies.
- RAM is monitored and over-limit processes are stopped, but this is not a
  hard kernel memory cgroup limit. There can be a short monitoring delay.
- CPU is monitored by the existing process monitor. Disk allocation is currently
  a plan/configuration value, not an enforced filesystem quota.
- A payment gateway and automated purchase/renewal workflow are not connected.
  They require a provider account and payment integration.
- The legacy `/api/create` provisioning endpoint is retained for compatibility.
  Restrict it with a reverse-proxy/API-key policy before exposing the service.
- `users.json`, `bots/`, SQLite databases and project logs are retained in this
  package. The app migrates the legacy admin record only when it first loads.

Existing bot source, database and output files have not been intentionally
rewritten as part of this update.
